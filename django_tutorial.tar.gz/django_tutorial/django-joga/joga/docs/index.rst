========================================
Welcome to this project's documentation!
========================================

This is a documentation template for a **web application based on Playdoh**.
Feel free to change this to your liking.


About playdoh
-------------

This project is based on **playdoh**. Mozilla's Playdoh is an open source
web application template based on `Django <http://www.djangoproject.com/>`_.

To learn more about it, step by the `playdoh project page
<https://github.com/mozilla/playdoh>`_.

Contents
--------

.. toctree::
   :maxdepth: 1


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
