import sys
import datetime
from django.db.models import Avg, Max, Min, Count
from django.db import models


class Participant(models.Model):
    # TODO: add optional nickname -OK
    name = models.CharField(max_length=255)
    nick = models.CharField(max_length=255, blank=True)
    email = models.EmailField(unique=True)

    def _get_active_season_ticket(self):
        # TODO: fix this to return the last active season ticket or None

        q1 = SeasonTicket.objects.all().filter(end_date__gte=datetime.date.today()).order_by('-start_date').reverse()[:1]
    #    print >>sys.stderr, 'LAST!!!!!!!!!!!!!SEARCH_BUG_BEGIN!!!!!!!!!!!!!'
    #    print >>sys.stderr, q1
    #    print >>sys.stderr, 'LAST!!!!!!!!!!!!!!SEARCH_BUG_END!!!!!!!!!!!!!!'

        if q1 :
            return q1[0]
        else :
            return None

    last_active_season_ticket = property(_get_active_season_ticket)

    def __unicode__(self):
        return self.nick if self.nick else self.name

    @models.permalink
    def get_absolute_url(self):
        return ('participants', (), {'pk': self.pk})


class Session(models.Model):
    # TODO: write a method to return the number of participants during a session
    # TODO: write a method to return the #Participants with a season and with a daily ticket
    name = models.CharField(max_length=255)
    participants = models.ManyToManyField(Participant, through='SessionParticipant')

    def _get_number_of_participants(self):
        q2 = Session.objects.annotate(num_participants=Count('participants'))
        number_of_participants = q2[0].num_participants
    #    print >>sys.stderr, 'NUM!!!!!!!!!!!!!SEARCH_BUG_BEGIN!!!!!!!!!!!!!'
    #    print >>sys.stderr, number_of_participants
    #    print >>sys.stderr, 'NUM!!!!!!!!!!!!!!SEARCH_BUG_END!!!!!!!!!!!!!!'
       
        return number_of_participants

    number_of_participants_per_session = property(_get_number_of_participants)

    
    def _get_participant_with_ticket(self):
        #Nem ertettem a feladatot: hogyan keszitsek daily ticket list-et, ha nincs naponkent tarolva a sesson?
        #reszeredmeny: egy tombben tarolja azokat a participant-okat, akiknek van season_ticket-uk
        q3 = Participant.objects.filter(session=self.pk, sessionparticipant__season_ticket__isnull=False)
        participant_with_ticket = q3
        print >>sys.stderr, 'WITH!!!!!!!!!!!!!SEARCH_BUG_BEGIN!!!!!!!!!!!!!'
        print >>sys.stderr, participant_with_ticket
        print >>sys.stderr, 'WITH!!!!!!!!!!!!!!SEARCH_BUG_END!!!!!!!!!!!!!!'

        return participant_with_ticket

    list_of_participants_with_tickets = property(_get_participant_with_ticket)


    def __unicode__(self):
        return self.name

    @models.permalink
    def get_absolute_url(self):
        return ('sessions', (), {'pk': self.pk})

    def participant_add(self, participant, paid=None):
        return SessionParticipant.objects.create(
            participant=participant,
            session=self,
            season_ticket=participant.last_active_season_ticket,
            paid=paid)


class SeasonTicket(models.Model):
    participant = models.ForeignKey(Participant)
    start_date = models.DateField(default=lambda: datetime.date.today())
    end_date = models.DateField(default=lambda: datetime.date.today()+datetime.timedelta(days=30))
    paid = models.DecimalField(max_digits=7, decimal_places=2)

    def __unicode__(self):
        return '%s (%s-%s)' % (self.participant, self.start_date, self.end_date)

    @models.permalink
    def get_absolute_url(self):
        return ('season_tickets', (), {'pk': self.pk})


class SessionParticipant(models.Model):
    participant = models.ForeignKey(Participant)
    session = models.ForeignKey(Session)
    season_ticket = models.ForeignKey(SeasonTicket, null=True)
    paid = models.DecimalField(max_digits=7, decimal_places=2, null=True)

    def __unicode__(self):
        return '%s - %s' % (self.participant, self.session)
