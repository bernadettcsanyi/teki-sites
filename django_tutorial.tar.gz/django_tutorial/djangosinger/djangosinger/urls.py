from django.conf.urls import patterns, include, url
from singers import views

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'djangosinger.views.home', name='home'),
    # url(r'^djangosinger/', include('djangosinger.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    url(r'^admin/', include(admin.site.urls)),
    url(r'^singers/', include('singers.urls')),
    url(r'^singers/(?P<savedsinger_id>\d+)/$', views.detail, name='detail'),
)
