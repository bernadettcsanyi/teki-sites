# Create your views here.
from django.http import HttpResponse
from django.http import Http404
from django.db import models
from singers.models import SavedSinger
from django.template import Context, loader
from django.shortcuts import render


def index(request):
    singer_list = SavedSinger.objects.all()
    template = loader.get_template('singers/index.html')
    context = Context({
        'singer_list': singer_list,
    })
    return HttpResponse(template.render(context))

def detail(request, savedsinger_id):
    try:
        savedsinger = SavedSinger.objects.get(pk=savedsinger_id)
    except SavedSinger.DoesNotExist:
        raise Http404
    return render(request, 'singers/detail.html', {'savedsinger': savedsinger})
