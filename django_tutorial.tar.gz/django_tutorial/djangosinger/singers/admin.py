from django.contrib import admin
from singers.models import SavedSinger

admin.site.register(SavedSinger)