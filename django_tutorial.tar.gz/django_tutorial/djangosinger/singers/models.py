from django.db import models

# Create your models here.

class SavedSinger(models.Model):
    picture = models.CharField(max_length=100, blank=True)
    singer_name = models.CharField(max_length=30, blank=False)
    short_desc = models.TextField(blank=True)
    format_place = models.CharField(max_length=50, blank=True)
    format_date = models.IntegerField(max_length=5, blank=True)

    def __unicode__(self):
        return u'%s %s %s' % (self.singer_name, self.short_desc, self.format_place)
